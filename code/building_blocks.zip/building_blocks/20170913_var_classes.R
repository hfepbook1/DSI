##################################################################
# June 2, 2017
# Jeff Goldsmith
#
# Script exploring vector classes
##################################################################

## create vectors
vec_numeric = 5:8
vec_char = c("My", "name", "is", "Jeff")
vec_logical = c(TRUE, TRUE, TRUE, FALSE)
vec_factor = factor(c("male", "male", "female", "female"))

## check class of vectors
class(vec_numeric)
class(vec_char)
class(vec_logical)
class(vec_factor)

## convert factor to numeric
as.numeric(vec_factor)






