##################################################################
# June 2, 2017
# Jeff Goldsmith
#
# Script producing basic plots
##################################################################

## set seed to ensure reproducibility
set.seed(1234)

## define x and y
x = rnorm(1000)
y = 1 + 2 * x + rnorm(1000, 0, .4)

## histogram of x
hist(x)

## scatterplot of y against x
plot(x2, y)
dev.print(pdf, "scatter_plot.pdf", height = 4, width = 4)




